import React from "react";
import "./articale.css";

import imageCurrency from "../../assets/img/image-currency.jpg";
import imageRestaurant from "../../assets/img/image-restaurant.jpg";
import imagePlane from "../../assets/img/image-plane.jpg";
import imageConfetti from "../../assets/img/image-confetti.jpg";

const Articles = () => {
  const articles = [
    {
      img: imageCurrency,
      author: "By Claire Robinson",
      title: "Receive money in any currency with no fees",
      text: "The world is getting smaller and we’re becoming more mobile. So why should you be forced to only receive money in a single …",
    },
    {
      img: imageRestaurant,
      author: "By Wilson Hutton",
      title: "Treat yourself without worrying about money",
      text: "Our simple budgeting feature allows you to separate out your spending and set realistic limits each month. That means you …",
    },
    {
      img: imagePlane,
      author: "By Wilson Hutton",
      title: "Take your Easybank card wherever you go",
      text: "We want you to enjoy your travels. This is why we don’t charge any fees on purchases while you’re abroad. We’ll even show you …",
    },
    {
      img: imageConfetti,
      author: "By Claire Robinson",
      title: "Our invite-only Beta accounts are now live!",
      text: "After a lot of hard work by the whole team, we’re excited to launch our closed beta. It’s easy to request an invite through the site …",
    },
  ];

  return (
    <section className="articales" id="articles">
      <div className="container">
        <h2>Latest Articles</h2>
        <div className="article-grid">
          {articles.map((article, index) => (
            <div key={index} className="article-card">
              <img src={article.img} alt={article.title} />
              <div className="articale-content">
                <p className="author">{article.author}</p>
                <h3>{article.title}</h3>
                <p>{article.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Articles;
