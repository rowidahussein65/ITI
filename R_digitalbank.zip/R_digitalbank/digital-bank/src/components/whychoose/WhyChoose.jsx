import React from "react";
import "./whychoose.css";
import iconOnline from "../../assets/img/icon-online.svg";
import iconBudgeting from "../../assets/img/icon-budgeting.svg";
import iconOnboarding from "../../assets/img/icon-onboarding.svg";
import iconApi from "../../assets/img/icon-api.svg";

const WhyChoose = () => {
  const features = [
    {
      icon: iconOnline,
      title: "Online Banking",
      description:
        "Our modern web and mobile applications allow you to keep track of your finances wherever you are in the world.",
    },
    {
      icon: iconBudgeting,
      title: "Simple Budgeting",
      description:
        "See exactly where your money goes each month. Receive notifications when you're close to hitting your limits.",
    },
    {
      icon: iconOnboarding,
      title: "Fast Onboarding",
      description:
        "We don't do branches. Open your account in minutes online and start taking control of your finances right away.",
    },
    {
      icon: iconApi,
      title: "Open API",
      description:
        "Manage your savings, investments, pension, and much more from one account. Tracking your money has never been easier.",
    },
  ];

  return (
    <section className="why-choose" id="features">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Why choose Easybank?</h2>
          <p className="section-subtitle">
            We leverage Open Banking to turn your bank account into your
            financial hub. Control your finances like never before.
          </p>
        </div>

        <div className="features-grid">
          {features.map((feature, index) => (
            <div
              className="feature-card"
              key={index}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="feature-icon">
                <img src={feature.icon} alt={feature.title} />
              </div>
              <h3 className="feature-title">{feature.title}</h3>
              <p className="feature-description">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChoose;
