import React, { useState } from "react";
import "./navbar.css";
import logo from "../../assets/img/logo-dark.svg";

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="container nav-container">
        <div className="left">
          <img src={logo} alt="Company Logo" className="logo-image" />
        </div>

        {/* Hamburger icon */}
        <div
          className={`menu-toggle ${menuOpen ? "open" : ""}`}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
        >
          <span></span>
          <span></span>
          <span></span>
        </div>

        {/* Navigation links */}
        <div className={`nav-links ${menuOpen ? "show" : ""}`}>
          <a href="#home" onClick={() => setMenuOpen(false)}>
            Home
          </a>
          <a href="#features" onClick={() => setMenuOpen(false)}>
            Features
          </a>
          <a href="#articles" onClick={() => setMenuOpen(false)}>
            Articles
          </a>
          <a href="#contact" onClick={() => setMenuOpen(false)}>
            Contact
          </a>
        </div>

        <a href="#request" className="btn request-btn">
          Request Invite
        </a>
      </div>
    </nav>
  );
};

export default Navbar;
