import React from "react";
import "./footer.css";
import logoWhite from "../../assets/img/logo-light.svg";

const Footer = () => {
  const socialLinks = [
    { icon: "fab fa-facebook-f", label: "Facebook" },
    { icon: "fab fa-youtube", label: "YouTube" },
    { icon: "fab fa-twitter", label: "Twitter" },
    { icon: "fab fa-pinterest-p", label: "Pinterest" },
    { icon: "fab fa-instagram", label: "Instagram" },
  ];

  const footerLinks = [
    [
      { text: "About Us", url: "#" },
      { text: "Contact", url: "#" },
      { text: "Blog", url: "#" },
    ],
    [
      { text: "Careers", url: "#" },
      { text: "Support", url: "#" },
      { text: "Privacy Policy", url: "#" },
    ],
  ];

  return (
    <footer className="footer" id="contact">
      <div className="container footer-container">
        {/* Brand Column */}
        <div className="footer-brand">
          <img
            src={logoWhite}
            alt="Easybank"
            className="footer-logo"
            width="140"
            height="20"
          />
          <div className="social-links">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href="#"
                aria-label={social.label}
                className="social-link"
              >
                <i className={social.icon}></i>
              </a>
            ))}
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="footer-nav">
          {footerLinks.map((linkGroup, groupIndex) => (
            <ul key={groupIndex} className="footer-link-group">
              {linkGroup.map((link, index) => (
                <li key={index}>
                  <a href={link.url} className="footer-link">
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          ))}
        </nav>

        {/* CTA Column */}
        <div className="footer-cta">
          <button className="btn-request">Request Invite</button>
          <p className="copyright">© Easybank. All Rights Reserved</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
