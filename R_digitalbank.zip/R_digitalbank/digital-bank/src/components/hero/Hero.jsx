import React from "react";
import "./hero.css";
import phonesImage from "../../assets/img/image-mockups.png";
import svgImage from "../../assets/img/bg-intro-desktop.svg";

const Hero = () => {
  return (
    <section className="hero" id="home">
      <div className="container hero-content">
        <div className="hero-text">
          <h2 className="hero-subtitle">Next generation digital banking</h2>
          <h1 className="hero-title">Take your financial life online</h1>
          <p className="hero-description">
            Easybank helps you take your financial life online. Your Easybank
            account will be a one-stop-shop for spending, saving, budgeting,
            investing, and much more.
          </p>
          <a href="#" className="btn hero-btn">
            Request Invite
          </a>
        </div>

        <div className="hero-image">
          <img src={svgImage} alt="" className="svg-image" aria-hidden="true" />
          <img
            src={phonesImage}
            alt="Easybank mobile app interface"
            className="phones-image"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;
