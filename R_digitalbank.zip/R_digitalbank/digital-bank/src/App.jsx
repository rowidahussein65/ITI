import React from "react";
import Navbar from "./components/header/Navbar";
import Hero from "./components/hero/Hero";
import WhyChoose from "./components/whychoose/WhyChoose";
import Articles from "./components/articale/Articale";
import Footer from "./components/footer/Footer";

function App() {
  return (
    <>
      <Navbar />
      <Hero />
      <WhyChoose />
      <Articles />
      <Footer />
    </>
  );
}

export default App;
